package app.controller;
import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import app.controller.request.CreationUserRequest;
import app.controller.validator.PartnerValidator;
import app.controller.validator.PersonValidator;
import app.controller.validator.UserValidator;
import app.dto.InvoiceDetailDto;
import app.dto.InvoiceDto;
import app.dto.PartnerDto;
import app.dto.PersonDto;
import app.dto.UserDto;
import app.service.ClubService;
import app.service.interfaces.AdminService;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
@RestController
public class AdminController {
        @Autowired
        private GuestController GuestController;
        @Autowired
        private PartnerController PartnerController;
	@Autowired
	private PersonValidator personValidator;
	@Autowired
	private UserValidator userValidator;
	@Autowired
	private PartnerValidator partnerValidator;
	@Autowired
	private ClubService service;
	//@Autowired
	private InvoiceDto invoiceDto;
	private static final String MENU = "ingrese la opcion que desea \n 1.para crear socio \n 2. para ver historial de facturas de el socio \n 3. para ver historial de facturas de invitado \n 4. para la promocion de facturas \n 5. para cerrar sesion \n";

	public void session() throws Exception {
		
	}
	
	
	@PostMapping("/partner")
	 private ResponseEntity createPartner(@RequestBody CreationUserRequest request ) throws Exception{ 
		try {
	    String name = request.getName();
		personValidator.validName(name);
	
	    long document = personValidator.validDocument(request.getDocument());
		
		long cellPhone = personValidator.validCellphone(request.getCellphone());
		
		String userName = request.getUserName() ;
		userValidator.validUserName(userName);
	
		String password = request.getPassword();
		userValidator.validPassword(password);
	        
		PersonDto personDto = new PersonDto();
		personDto.setName(name);
		personDto.setDocument(document);
		personDto.setCellphone(cellPhone);
		UserDto userDto = new UserDto();
		userDto.setPersonId(personDto);
		userDto.setUserName(userName);
		userDto.setPassword(password);
		userDto.setRole("partner");          
	        PartnerDto partnerDto = new PartnerDto();
	        partnerDto.setUserTol(userDto);
	        partnerDto.setType(true);
	        partnerDto.setAmount(50000);
	        partnerDto.setCreationDate(new Date(System.currentTimeMillis()));
	        this.service.createPartner(partnerDto);
		
		return new ResponseEntity<>("se ha creado el partner exitosamente",HttpStatus.OK);
		} catch(Exception e){
			return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
			}	
		}
	      
	
	
	/* public void showAllInvoicesPartner(InvoiceDto invoiceDto, InvoiceDetailDto invoiceDetailDto) {
		    System.out.println("Mostrando factura del socio");
		    
		 
		    PartnerController.invoiceHistory(invoiceDto, invoiceDetailDto);
		}

        
        public void showAllInvoicesGuest(InvoiceDto invoiceDto, InvoiceDetailDto invoiceDetailDto){
        System.out.println("mostrando factura del invitado");
        GuestController.invoiceHistory(invoiceDto, invoiceDetailDto);
        }*/
	
	@GetMapping("/invoices")
    private ResponseEntity invoiceHistory() throws Exception{
        try {
            List<InvoiceDetailDto> listInvoicesDetailDto = this.service.invoiceHistory();
            return new ResponseEntity <>(listInvoicesDetailDto,HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
       
        
    }
	
	
	@PutMapping("/vipPromotion")
    private ResponseEntity vipPromotion() throws Exception{
        try {
            this.service.vipPromotion();
            return new ResponseEntity<>("ha sido promovido",HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
        
    }
	@GetMapping("/invoiceHistoryPartner/{document}")
    private ResponseEntity invoiceHistoryPartner(@PathVariable long document) throws Exception{
        try {
            List<InvoiceDetailDto> listInvoicesDetailDto = this.service.invoiceHistoryPartner(document);
            return new ResponseEntity<>(listInvoicesDetailDto,HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
        
    }
    @GetMapping("/invoiceHistoryGuest/{document}")
    private ResponseEntity invoiceHistoryGuest(@PathVariable long document) throws Exception{
        try {
            List<InvoiceDetailDto> listInvoicesDetailDto = this.service.invoiceHistoryGuest(document);
            return new ResponseEntity <>(listInvoicesDetailDto,HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
       
        
    }




}
