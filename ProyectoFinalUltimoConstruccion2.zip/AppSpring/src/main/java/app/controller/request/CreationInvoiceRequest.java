package app.controller.request;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CreationInvoiceRequest {
	 private String item;
	    private String description;
	    private String amount;
	    private long userSesion;
		public String getItem() {
			return item;
		}
		public void setItem(String item) {
			this.item = item;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getAmount() {
			return amount;
		}
		public void setAmount(String amount) {
			this.amount = amount;
		}
		public long getUserSesion() {
			return userSesion;
		}
		public void setUserSesion(long userSesion) {
			this.userSesion = userSesion;
		}
		
}
