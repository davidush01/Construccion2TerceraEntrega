package app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.sql.Date;

import app.controller.request.CreationAmount;
import app.controller.request.CreationInvoiceRequest;
import app.controller.request.CreationUserRequest;
import app.controller.validator.DetailValidator;
import app.controller.validator.InvoiceValidator;
import app.controller.validator.PartnerValidator;
import app.controller.validator.PersonValidator;
import app.controller.validator.UserValidator;
import app.controller.validator.GuestValidator;
import app.dto.GuestDto;
import app.dto.InvoiceDetailDto;
import app.dto.InvoiceDto;
import app.dto.PartnerDto;
import app.dto.PersonDto;
import app.dto.UserDto;
import app.service.ClubService;
import app.service.interfaces.AdminService;
import app.service.interfaces.GuestService;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor

@RestController
public class PartnerController {
    private List<InvoiceDto> invoiceList = new ArrayList<>();
    @Autowired
    private UserValidator UserValidator;
	@Autowired
	private PersonValidator personValidator;
	@Autowired
	private PartnerValidator partnerValidator;
	@Autowired
	private InvoiceValidator invoiceValidator;
	@Autowired
	private DetailValidator detailValidator;
	@Autowired
	private GuestValidator guestValidator;
	@Autowired
	private ClubService Service;
	
	private static final String MENU = "Ingrese la opcion la accion que desea hacer \n 1. para crear invitado. \n 2. para activar invitado \n 3. para desactivar invitado \n 4. para hacer consumo \n 5.para solicitar baja \n 6. para cerrar sesion \n";

	ClubService service = new ClubService();
	
	public void session() throws Exception {
		

	    }
	

	
	/*public void invoiceHistory(InvoiceDto invoiceDto, InvoiceDetailDto invoiceDetailDto) {
	    System.out.println("Detalles de la Factura:");
	    System.out.println("----------------------");
	    System.out.println("ID de la Persona: " + invoiceDto.getPersonId().getId());
	    System.out.println("ID del Socio: " + invoiceDto.getPartnerId().getId());
	    System.out.println("Estado: " + invoiceDto.isStatus());
	    System.out.println("Monto: " + invoiceDto.getAmount());
	    System.out.println("Fecha de Creación: " + invoiceDto.getCreationDate());
	    
	    System.out.println("\nDetalles de la Línea de Factura:");
	    System.out.println("-------------------------------");
	    System.out.println("ID de la Factura: " + invoiceDetailDto.getInvoiceId().getId());
	    System.out.println("Ítem: " + invoiceDetailDto.getItem());
	    System.out.println("Descripción: " + invoiceDetailDto.getDescription());
	    System.out.println("Monto de la Línea: " + invoiceDetailDto.getAmount());
	}*/
    @PostMapping("/createInvoicePartner")
	private ResponseEntity createInvoicePartner(@RequestBody CreationInvoiceRequest request) throws Exception {
	  try {
	    int item = invoiceValidator.validItem(request.getItem());
	   
	    String description = request.getDescription();
	    invoiceValidator.validDescription(description);
	    
	  
	    double amount = invoiceValidator.validAmount(request.getAmount());

	    PersonDto personDto = new PersonDto(); 
	    PartnerDto partnerDto = new PartnerDto();
	    partnerDto.setId(request.getUserSesion());

	    InvoiceDto invoiceDto = new InvoiceDto();
	    invoiceDto.setPersonId(personDto);
	    invoiceDto.setPartnerId(partnerDto);
	    invoiceDto.setStatus(false);
	    invoiceDto.setAmount(amount);
	    invoiceDto.setCreationDate(Utils.getDate());

	    InvoiceDetailDto invoiceDetailDto = new InvoiceDetailDto();
	    invoiceDetailDto.setInvoiceId(invoiceDto);
	    invoiceDetailDto.setItem(item);
	    invoiceDetailDto.setDescription(description);
	    invoiceDetailDto.setAmount(amount);
	    
	    this.service.createInvoiceDetail(invoiceDetailDto);
	   
	    return new ResponseEntity<>("se ha creado la factura exitosamente",HttpStatus.OK);
		}catch(Exception e){
			return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
			
			
			
		}
	}

       
    /*@PostMapping("/createGuest")
    private ResponseEntity CreateGuest( @RequestBody CreationUserRequest request ) throws Exception{
        try {
            String name = request.getName();
            personValidator.validName(name);
            
            long document = personValidator.validDocument(request.getDocument());
            long cellPhone = personValidator.validCellphone(request.getCellphone());
            
            String userName = request.getUserName();
            UserValidator.validUserName(userName);
            
            String password = request.getPassword();
            UserValidator.validPassword(password);
            
            PersonDto personDto = new PersonDto();
            personDto.setName(name);
            personDto.setDocument(document);
            personDto.setCellphone(cellPhone);
            
            UserDto userDto = new UserDto();
            userDto.setPersonId(personDto);
            userDto.setUserName(userName);
            userDto.setPassword(password);
            userDto.setRole("guest");
            
            PartnerDto partnerDto = new PartnerDto();
            partnerDto.setId(request.getUserSesion());
            
            GuestDto guestDto = new GuestDto();
            guestDto.setUserId(userDto);
            guestDto.setPartnerId(partnerDto);
            guestDto.setStatus(false);
            this.service.createGuest(guestDto);
            return new ResponseEntity<>("se ha creado el initado exitosamente", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }*/
    @PostMapping("/createGuest")
    private ResponseEntity<String> createGuest(@RequestBody CreationUserRequest request) {
        try {
            // Validaciones de entrada
            String name = request.getName();
            personValidator.validName(name);
            
            long document = personValidator.validDocument(request.getDocument());
            long cellPhone = personValidator.validCellphone(request.getCellphone());
            
            String userName = request.getUserName();
            UserValidator.validUserName(userName);
            
            String password = request.getPassword();
            UserValidator.validPassword(password);
            
            // Crear PersonDto
            PersonDto personDto = new PersonDto();
            personDto.setName(name);
            personDto.setDocument(document);
            personDto.setCellphone(cellPhone);

            // Crear UserDto
            UserDto userDto = new UserDto();
            userDto.setPersonId(personDto); // Esto establecerá la relación entre User y Person
            userDto.setUserName(userName);
            userDto.setPassword(password);
            userDto.setRole("guest");

            // Crear PartnerDto
            PartnerDto partnerDto = new PartnerDto();
            partnerDto.setId(request.getUserSesion());

            // Crear GuestDto
            GuestDto guestDto = new GuestDto();
            guestDto.setUserId(userDto); // Relacionando UserDto con GuestDto
            guestDto.setPartnerId(partnerDto); // Relacionando PartnerDto con GuestDto
            guestDto.setStatus(false); // Estado del invitado
            
         
            this.service.createGuest(guestDto);

            return new ResponseEntity<>("Se ha creado el invitado exitosamente", HttpStatus.OK);
        } catch (Exception e) {
            // Retornar el mensaje de error si algo falla
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

        
	
    @PutMapping("incrementAmount")
    private ResponseEntity incrementAmount(@RequestBody CreationAmount request) throws Exception{
        try {
            double amount = partnerValidator.validAmount(request.getAmount());   
            PartnerDto partnerDto = new PartnerDto();
            partnerDto.setId(request.getUserSesion());
            partnerDto.setAmount(amount);
            this.service.incrementAmount(partnerDto);
            return new ResponseEntity <>("fondos incrementados",HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    @PutMapping("disable-guest/{document}")
    private ResponseEntity disableGuest(@PathVariable long document)throws Exception{
        try {
            this.service.disableGuest(document);
            return new ResponseEntity <>("invitado desactivado",HttpStatus.OK);
        } catch (Exception e) {
           return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST); 
        }
        
    }
    
    @PutMapping("activate-guest/{document}")
    private ResponseEntity activateGuest(@PathVariable long document)throws Exception{
        try {
            this.service.activateGuest(document);
            return ResponseEntity.ok("invitado activado");
        } catch (Exception e) {
           return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST); 
        }
    }

    @PutMapping("Request-vip/{partnerId}")
    private ResponseEntity PartnerRequestVip(@PathVariable long partnerId) throws Exception{
        try {
            PartnerDto partnerDto = new PartnerDto();
            partnerDto.setId(partnerId);
            partnerDto.setType(false);
            String response = this.service.PartnerRequestVip(partnerDto);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
	
	 
	 /*@PutMapping("vip promotion")
	 private ResponseEntity vipPromotion() throws Exception {
	     try {
	         PartnerDto partnerDto = new PartnerDto();
	         partnerDto.setType(true);
	         return new ResponseEntity<>("Socio ascendido a VIP", HttpStatus.OK);
	     } catch (Exception e) {
	         return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
	     }
	 }*/

	 @PutMapping("request-unsubscribe/{document}")
	 private ResponseEntity requestUnsubscribe(@PathVariable long document) throws Exception {
	     try {
	        

	         document = personValidator.validDocument(Utils.getReader().nextLine());

	         PartnerDto partnerDto = this.service.findPartnerByDocument(document);

	         if (partnerDto == null) {
	             return new ResponseEntity<>("No se ha encontrado un socio con ese documento", HttpStatus.NOT_FOUND);
	         }

	         InvoiceDto pendingInvoice = (InvoiceDto) this.service.invoiceHistoryPartner(document);
	         if (pendingInvoice != null && !pendingInvoice.isStatus()) {
	             return new ResponseEntity<>("El socio tiene facturas pendientes. No puede ser convertido en invitado hasta que las facturas sean pagadas.", HttpStatus.BAD_REQUEST);
	         }

	         GuestDto guestDto = new GuestDto();
	         guestDto.setUserId(partnerDto.getUserTol());
	         guestDto.setPartnerId(null);
	         guestDto.setStatus(true);

	         this.service.createGuest(guestDto);
	         this.service.disablePartner(partnerDto.getId());

	         return new ResponseEntity<>("El socio ha bajado exitosamente a invitado.", HttpStatus.OK);
	     } catch (Exception e) {
	         return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
	     }
	 }



    }
    

	
