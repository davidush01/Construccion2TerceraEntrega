package app.dao.interfaces;
import java.util.List;

import app.dto.InvoiceDto;

public interface InvoiceDao {
    public void createInvoice(InvoiceDto invoiceDto) throws Exception;
    public  List<InvoiceDto> listInvoices() throws Exception;
   // public InvoiceDto findByParnert() throws Exception;
}
