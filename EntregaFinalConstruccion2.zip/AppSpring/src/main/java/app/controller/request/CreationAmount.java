package app.controller.request;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CreationAmount {
	 private String amount;
	    private long userSesion;


public String getAmount() {
	return amount;
}
public void setAmount(String amount) {
	this.amount = amount;
}
public long getUserSesion() {
	return userSesion;
}
public void setUserSesion(long userSesion) {
	this.userSesion = userSesion;
}


	    
}
