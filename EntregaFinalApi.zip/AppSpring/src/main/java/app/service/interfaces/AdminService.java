package app.service.interfaces;

import app.dto.PartnerDto;
import app.dto.UserDto;
import app.dto.InvoiceDetailDto;

import java.util.List;


public interface AdminService {
	public void createPartnerRegistration(PartnerDto partnerdto) throws Exception;

	public void createViewInvoiceHistory(UserDto userDto) throws Exception;

	public void vipPromotion() throws Exception;
	public List<InvoiceDetailDto> invoiceHistory () throws Exception;
    public List<InvoiceDetailDto> invoiceHistoryPartner(long document) throws Exception;
    public List<InvoiceDetailDto> invoiceHistoryGuest(long document) throws Exception;
}
	
	

 