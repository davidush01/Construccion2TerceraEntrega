package app.service.interfaces;

/*public void createInvoice() throws Exception {
System.out.println("ingrese el documento de el que realiza el consumo ");
long document = personValidator.validDocument(Utils.getReader().nextLine());
System.out.println("ingrese el documento de el socio que paga el consumo");
long partnerDocument = partnerValidator.validDocument(Utils.getReader().nextLine());
System.out.println("ingrese el valor de la factura");
double amount = invoiceValidator.validAmount(Utils.getReader().nextLine());
System.out.println("ingrese el estado de la factura (pagada / sin pagar");
String status = Utils.getReader().nextLine();
invoiceValidator.isValidboolean(status);
InvoiceDto invoiceDto = new InvoiceDto();
PartnerDto partnerDto = new PartnerDto();
PersonDto personDto = new PersonDto();
personDto.setDocument(document);
partnerDto.setId(partnerDocument);
invoiceDto.setAmount(amount);
invoiceDto.setCreationDate(new Date(System.currentTimeMillis()));
System.out.println("se creo la factura");

}*/

/*public void createInvoiceDetail() throws Exception {

System.out.println("Ingrese el ID del encabezado de la factura:");
long invoiceHeaderId = DetailValidator.(Utils.getReader().nextLine());

System.out.println("Ingrese el número de ítem (único por factura):");
int itemNumber = DetailValidator.(Utils.getReader().nextLine());

System.out.println("Ingrese la descripción del ítem consumido):");
String description = DetailValidator.(Utils.getReader().nextLine());

System.out.println("Ingrese el valor del ítem:");
double itemamount = DetailValidator.(Utils.getReader().nextLine());

InvoiceDetailDto invoiceDetailDto = new InvoiceDetailDto();
invoiceDetailDto.setInvoiceId(invoiceHeaderId);
invoiceDetailDto.setItem(itemNumber);
invoiceDetailDto.setDescription(description);
invoiceDetailDto.setAmount(itemamount);

System.out.println("Se creó el detalle de la factura");
}*/

