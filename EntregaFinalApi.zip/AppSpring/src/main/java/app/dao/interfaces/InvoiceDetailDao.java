package app.dao.interfaces;

import java.util.List;

import app.dto.InvoiceDetailDto;


public interface InvoiceDetailDao {
    public void createInvoiceDetail( InvoiceDetailDto invoiceDetailDto ) throws Exception;
    public List<InvoiceDetailDto> listInvoices() throws Exception;
}