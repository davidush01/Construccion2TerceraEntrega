package app.dao.Repository;


import app.model.InvoiceDetail;
import org.springframework.data.jpa.repository.JpaRepository;


public interface InvoiceDetailRepository extends JpaRepository<InvoiceDetail,Long>{
    
}
